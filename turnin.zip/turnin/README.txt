To compile the program, a version of the Java Development Kit (JDK) higher than 8 must be installed on the system.

To compile, type the following into the command line:
javac Project.java

To run, type the following into the command line:
java Project

When prompted, enter the input in the format requested